import json


def update_json_file(jp, data):
    with open(jp, 'w+') as f:
        json.dump(data, f)
        f.close()


