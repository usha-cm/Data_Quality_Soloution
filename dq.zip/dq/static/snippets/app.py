import datetime
import os

from flask import Flask, render_template, request
from static.scripts.write_input_data import update_json_file

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
@app.route('/dqformdev', methods=['GET', 'POST'])
def dqformdev(jp='static/files/inputs.json'):
    cloud_server = {}
    if request.method == 'POST':
        cloud_server["server_path"] = request.form['dpes-dq-server-path']
        cloud_server["server_name"] = request.form['dpes-dq-file-name']
        cloud_server["server_username"] = request.form['dpes-dq-user-name']
        cloud_server["server_password"] = request.form['dpes-dq-password']
        cloud_server["current_user"] = str(os.getlogin())
    else:
        cloud_server["server_path"] = ""
        cloud_server["server_name"] = ""
        cloud_server["server_username"] = ""
        cloud_server["server_password"] = ""
        cloud_server["current_user"] = ""
    update_json_file(jp, cloud_server)
    return render_template('dev-dpes-dq-form.html')

    s3 = {}
    if request.method == 'POST':
        s3["s3_path"] = request.form['dpes-dq-s3-path']
        s3["s3_bucket"] = request.form['dpes-dq-bucket-name']
        s3["s3_a_key"] = request.form['dpes-dq-access-key']
        s3["s3_p_key"] = request.form['dpes-dq-secret-key']
        s3["dttm"] = str(datetime.datetime.now())
        s3["current_user"] = str(os.getlogin())
    else:
        s3["s3_path"] = ""
        s3["s3_bucket"] = ""
        s3["s3_a_key"] = ""
        s3["s3_p_key"] = ""
        s3["dttm"] = ""
    update_json_file(jp, s3)
    return render_template('dev-dpes-dq-form.html')



if __name__ == '__main__':
    app.run(debug=True)
