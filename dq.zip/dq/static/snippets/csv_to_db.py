import pandas as pd
from pymongo import MongoClient

# Step 1: Read the CSV file
csv_file_path = 'validation_results.csv'  # Update with your CSV file path
df = pd.read_csv(csv_file_path)

# Step 2: Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')  # Update with your MongoDB connection string if necessary
db = client['DQSolutions']  # Replace 'your_database' with your database name
collection = db['results']  # Replace 'your_collection' with your collection name

# Step 3: Insert data into MongoDB
data_dict = df.to_dict('records')
collection.insert_many(data_dict)

print("CSV data has been imported into MongoDB")

