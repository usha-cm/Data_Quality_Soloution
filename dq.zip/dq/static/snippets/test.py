from flask import Flask, request, redirect, url_for, render_template
import os

app = Flask(__name__)

# Configure the upload folder
UPLOAD_FOLDER = 'static/files'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


@app.route('/')
def upload_file():
    return render_template('dev-dpes-dq-form.html')


@app.route('/', methods=['GET', 'POST'])
@app.route('/dqformdev', methods=['GET', 'POST'])
def dqformdev(jp='static/files'):
    if 'file' not in request.files:
        return 'No file part'

    file = request.files['file']

    if file.filename == '':
        return 'No selected file'

    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        return f'File successfully uploaded to {file_path}'


if __name__ == '__main__':
    app.run(debug=True,port=5001)
