import datetime
from urllib.parse import urlparse
import pandas as pd
import json
import boto3
import os
from flask import Flask, flash, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename
from static.scripts.write_input_data import update_json_file
from DQsolutions import dpes_dq_data_completeness
from DQsolutions import dpes_dq_data_consistency
from DQsolutions import dpes_dq_file_integrity
from DQsolutions import dpes_dq_file_metadata
from DQsolutions.dq_validation import validate_file
import great_expectations as gx
import paramiko
from dotenv import load_dotenv, set_key, dotenv_values
import botocore

load_dotenv()
app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
UPLOAD_FOLDER = 'static/files'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def update_env_file(key, value):
    env_path = '.env'
    dotenv_values(env_path)
    set_key(env_path, key, value)


def upload_to_s3(file_path, s3_folder, s3_key_prefix=None):
    s3_client = boto3.client(
        's3',
        aws_access_key_id=os.getenv("MY_S3_ACCESS_KEY"),
        aws_secret_access_key=os.getenv("MY_S3_SECRET_KEY")
    )
    
    try:
        s3_file_name = os.path.basename(file_path) 
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        user = os.getlogin()
        
        if s3_key_prefix:
            s3_key = f"{s3_folder}/{s3_key_prefix}_{user}_{timestamp}_{s3_file_name}"
        else:
            s3_key = f"{s3_folder}/{s3_file_name}"
        
        print(f"Uploading to S3 with key: {s3_key}")
        
        s3_client.upload_file(file_path, 'inputarchieves', s3_key)
        print(f"File successfully uploaded to S3 bucket with key: {s3_key}")
    
    except boto3.exceptions.S3UploadFailedError as e:
        print(f"Upload failed: {e}")
    except boto3.exceptions.Boto3Error as e:
        print(f"An error occurred: {e}")


def download_from_ec2(cloud_srvr, local_file_path):
    try:
        hostname = cloud_srvr["server_name"]
        port = 22 
        username = cloud_srvr["server_a_key"]
        password = os.getenv("SERVER_PASSWORD")
        remote_file_path = cloud_srvr["server_path"]

        # Create an SSH client instance
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        # Connect to the EC2 instance
        ssh.connect(hostname, port=port, username=username, password=password)
        
        # Create an SFTP session
        sftp = ssh.open_sftp()
        
        # Download the file
        sftp.get(remote_file_path, local_file_path)
        
        # Close the SFTP session and SSH connection
        sftp.close()
        ssh.close()
        
        print(f"File successfully downloaded from {remote_file_path} to {local_file_path}")
    
    except paramiko.AuthenticationException as e:
        print(f"Authentication failed: {e}")
    except paramiko.SSHException as e:
        print(f"SSH connection error: {e}")
    except FileNotFoundError as e:
        print(f"File not found error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
    


def download_from_s3(s3_details, file_path):
    s3_client = boto3.client(
        's3',
        aws_access_key_id=os.getenv("S3_ACCESS_KEY"),
        aws_secret_access_key=os.getenv("S3_SECRET_KEY")
    )
    try:
        bucket_name = s3_details["s3_bucket"]
        s3_key = s3_details["s3_path"]
        
        print(f"Attempting to download from bucket: {bucket_name} with key: {s3_key}")
        
        s3_client.download_file(bucket_name, s3_key, file_path)
        print(f"File successfully downloaded to {file_path}")

    except botocore.exceptions.ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'NoSuchBucket':
            print(f"Error: The specified bucket does not exist: {e}")
        elif error_code == 'NoSuchKey':
            print(f"Error: The specified key does not exist: {e}")
        else:
            print(f"Error: An unexpected error occurred: {e}")
    except boto3.exceptions.Boto3Error as e:
        print(f"Error: An unexpected Boto3 error occurred: {e}")


def process_file(fp, config_path):
    with open(config_path, 'r') as config_file:
        config = json.load(config_file)

    config["etl_fpath"] = fp

    df = pd.read_csv(fp, dtype='str')
    dff = pd.read_csv(fp)

    exp_emp_hdr = dff.columns.tolist()
    exp_dt = [f"{col} : {dff[col].dtype}" for col in dff.columns]

    config["exp_emp_hdr"] = exp_emp_hdr
    config["exp_dt"] = exp_dt

    with open(config_path, 'w') as config_file:
        json.dump(config, config_file, indent=4)
    
    dpes_dq_file_integrity.check_file_permissions(fp)
    file_metadata = dpes_dq_file_metadata.get_file_metadata(fp)
    dpes_dq_file_metadata.find_header_match(df, config_path)
    dpes_dq_data_completeness.get_special_characters(dff)
    print(f"\nThe file has {dpes_dq_data_consistency.get_duplicate_file_rows(df)} duplicate rows")
    dpes_dq_file_metadata.save_to_csv(fp)
    dpes_dq_data_consistency.find_data_type_inconsistency(dff)
    return fp, config_path


@app.route('/', methods=['GET', 'POST'])
def show_form():
    return render_template('dev-dpes-dq-form.html')


@app.route('/dqformdev', methods=['GET', 'POST'])
def dqformdev(jp='static/files/input.json'):
    src_opted = request.form.get('choice')

   
    match src_opted:
        case 'r1':
            if 'file' not in request.files:
                return 'No file part'
            file = request.files['file']
            if file.filename == '':
                return 'No selected file'
            if file:
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                file.save(file_path)
                unique_fields = [
                    'ssn', 'email', 'phone', 'medical_record_numbers', 'account_numbers', 
                    'certificate_license_numbers', 'vehicle_identifiers_serial_numbers', 
                    'device_identifiers_serial_numbers', 'ip_address_numbers',
                    'passport_number', 'visa_permits_number', 'drivers_license_number', 
                    'vehicle_registration_plate_number', 'credit_debit_card_number', 
                    'pan_card', 'adhar_card', 'insurance_policy_number', 
                    'health_plan_beneficiary_numbers'
                ]
                validate_file(file_path, unique_fields)
                file_path, json_path = process_file(file_path, jp)
                file_details = {
                    'dttm': str(datetime.datetime.now()),
                    'current_user': os.getlogin(),
                    'etl_fpath': file_path,
                    'exp_emp_hdr': pd.read_csv(file_path).columns.tolist(),
                    'exp_dt': [f"{col} : {pd.read_csv(file_path)[col].dtype}" for col in pd.read_csv(file_path).columns]
                }
                update_json_file(jp, file_details)
                base_filename = os.path.splitext(filename)[0]
                upload_to_s3(file_path, 'CSV Files', base_filename)
                upload_to_s3(json_path, 'Input_json_files', base_filename)
                return f'File successfully uploaded to {file_path}'

        case 'r2':
            cloud_srvr = {}
            if request.method == 'POST':
                cloud_srvr["server_path"] = request.form['dpes-dq-server-path']
                cloud_srvr["server_name"] = request.form['dpes-dq-file-name']
                cloud_srvr["server_a_key"] = request.form['dpes-dq-user-name']
                update_env_file('SERVER_PASSWORD', request.form['dpes-dq-password'])
                cloud_srvr["dttm"] = str(datetime.datetime.now())
                cloud_srvr["current_user"] = str(os.getlogin())
            update_json_file(jp, cloud_srvr)
            sftp_file_name = os.path.basename(cloud_srvr["server_path"])
            local_file_path = os.path.join(app.config['UPLOAD_FOLDER'], sftp_file_name)
            download_from_ec2(cloud_srvr, local_file_path)
            unique_fields = [
                    'ssn', 'email', 'phone', 'medical_record_numbers', 'account_numbers', 
                    'certificate_license_numbers', 'vehicle_identifiers_serial_numbers', 
                    'device_identifiers_serial_numbers', 'ip_address_numbers',
                    'passport_number', 'visa_permits_number', 'drivers_license_number', 
                    'vehicle_registration_plate_number', 'credit_debit_card_number', 
                    'pan_card', 'adhar_card', 'insurance_policy_number', 
                    'health_plan_beneficiary_numbers'
                ]
            validate_file(local_file_path, unique_fields)
            local_file_path, json_path = process_file(local_file_path, jp)
            original_file_name = os.path.splitext(sftp_file_name)[0]
            upload_to_s3(local_file_path, 'CSV Files', original_file_name)
            upload_to_s3(json_path, 'Input_json_files', original_file_name)
            return f'File successfully downloaded from EC2 to {local_file_path}'
        


        case 'r3':
            s3 = {}
            if request.method == 'POST':
                s3["s3_path"] = request.form['dpes-dq-s3-path']
                s3["s3_bucket"] = request.form['dpes-dq-bucket-name']
                update_env_file('S3_ACCESS_KEY', request.form['dpes-dq-access-key'])
                update_env_file('S3_SECRET_KEY', request.form['dpes-dq-secret-key'])
                s3["dttm"] = str(datetime.datetime.now())
                s3["current_user"] = str(os.getlogin())
                
            update_json_file(jp, s3)
            s3_file_name = os.path.basename(s3["s3_path"])
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], s3_file_name) 
            download_from_s3(s3, file_path)   
            unique_fields = [
                    'ssn', 'email', 'phone', 'medical_record_numbers', 'account_numbers', 
                    'certificate_license_numbers', 'vehicle_identifiers_serial_numbers', 
                    'device_identifiers_serial_numbers', 'ip_address_numbers',
                    'passport_number', 'visa_permits_number', 'drivers_license_number', 
                    'vehicle_registration_plate_number', 'credit_debit_card_number', 
                    'pan_card', 'adhar_card', 'insurance_policy_number', 
                    'health_plan_beneficiary_numbers'
                ]
            validate_file(file_path, unique_fields)
            process_file(file_path, jp)
            file_path, json_path = process_file(file_path, jp)
            original_file_name = os.path.basename(s3["s3_path"]).split('.')[0]
            upload_to_s3(file_path, 'CSV Files', original_file_name)
            upload_to_s3(json_path, 'Input_json_files', original_file_name)
            return f'File successfully downloaded from S3 to {file_path}'


    return render_template('dev-dpes-dq-form.html')


if __name__ == '__main__':
    app.run(debug=True,port=5001)
