import pandas as pd
import string


# Function to count special characters in a string
def count_special_chars(s):
    if pd.isnull(s):
        return 0
    special_chars = set(string.punctuation)
    return sum(1 for char in str(s) if char in special_chars)


# Initialize a dictionary to store the results
def get_special_characters(df):
    results = {
        'column_name': [],
        'num_nulls': [],
        'num_special_chars': []
    }
    # Iterate over each column in the dataframe
    for column in df.columns:
        num_nulls = df[column].isnull().sum()
        num_special_chars = df[column].apply(count_special_chars).sum()

        results['column_name'].append(column)
        results['num_nulls'].append(num_nulls)
        results['num_special_chars'].append(num_special_chars)

    # Convert results dictionary to a DataFrame
    results_df = pd.DataFrame(results)

    # Save results to a CSV file
    output_filename = 'column_analysis.csv'
    results_df.to_csv(output_filename, index=False)

    # Display results as a dictionary
    results_dict = results_df.to_dict(orient='list')
    validate_count = pd.read_csv(output_filename)
    print(f"\n{validate_count}")
