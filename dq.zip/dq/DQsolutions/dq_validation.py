import pandas as pd
import great_expectations as gx

def validate_file(file_path, unique_fields):
    context = gx.get_context()
    validator = context.sources.pandas_default.read_csv(file_path)

    pii_patterns = {
    'name': r"^[a-zA-Z\s']+$",  
    'middle_name': r"^[a-zA-Z\s']+$",  
    'last_name': r"^[a-zA-Z\s']+$",  
    'name_prefix': r"^[a-zA-Z\s.]+$",  
    'age': r'^\d+$',  
    'dob': r'^\d{4}-\d{2}-\d{2}$',  
    'ssn': r'^\d{9}$',  
    'mobile_number': r'^\d{10}$',  
    'telephone_number': r'^\d{10}$',  
    'fax_number': r'^\d{10}$',  
    'email': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',  
    'website_url': r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+',  
    'address_line_1': r'.+',  
    'city': r'.+',  
    'state_province': r'.+',  
    'zip_code': r'.+',  
    'country': r'.+',  
    'latitude': r'^[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?)$',  
    'longitude': r'^[-+]?((1[0-7]\d(\.\d+)?|1[0-8]0(\.0+)?|([1-9]?\d(\.\d+)?)))$',  
    'is_married': r'^(True|False)$',  
    'marriage_date': r'^\d{4}-\d{2}-\d{2}$',  
    'have_children': r'^(True|False)$',  
    'no_of_children': r'^\d+$',  
    'highest_qualification': r'^(True|False)$',  
    'employer_name': r"^[a-zA-Z\s']+$",  
    'occupation': r"^[a-zA-Z\s']+$",  
    'emergency_contact_name': r"^[a-zA-Z\s']+$",  
    'emergency_contact_phone_number': r'^\d{10}$',  
    'ethnicity_race': r"^[a-zA-Z\s]+$",  
    'passport_number': r"^[a-zA-Z0-9\s]+$",  
    'visa_permits_number': r"^[a-zA-Z0-9\s]+$",  
    'drivers_license_number': r"^[a-zA-Z0-9\s]+$",  
    'vehicle_registration_plate_number': r"^[a-zA-Z0-9\s]+$",  
    'credit_debit_card_number': r"^\d{16}$",  
    'pan_card': r"^[a-zA-Z0-9\s]+$",  
    'adhar_card': r"^\d{12}$", 
} 
    phi_patterns = {
    'biometric_identifiers': r'.+',  
    'full_face_photographic_images': r'.+\.(jpeg|jpg|png)$', 
    'medical_record_numbers': r"^[a-zA-Z0-9\s]+$", 
    'admission_date': r'^\d{4}-\d{2}-\d{2}$', 
    'discharge_date': r'^\d{4}-\d{2}-\d{2}$', 
    'death_date': r'^\d{4}-\d{2}-\d{2}$',  
    'health_plan_beneficiary_numbers': r"^[a-zA-Z0-9\s]+$",  
    'account_numbers': r"^[a-zA-Z0-9\s]+$",  
    'certificate_license_numbers': r"^[a-zA-Z0-9\s]+$", 
    'vehicle_identifiers_serial_numbers': r"^[a-zA-Z0-9\s]+$", 
    'device_identifiers_serial_numbers': r"^[a-zA-Z0-9\s]+$",  
    'ip_address_numbers': r"^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$",  
    'medical_history': r"^[a-zA-Z0-9\s]+$",  
    'current_medications': r"^[a-zA-Z0-9\s]+$",  
    'allergies': r"^[a-zA-Z0-9\s]+$",  
    'primary_care_physician': r"^[a-zA-Z0-9\s]+$", 
    'insurance_provider': r"^[a-zA-Z0-9\s]+$", 
    'insurance_policy_number': r"^[a-zA-Z0-9\s]+$", 
    'blood_type': r'^(A|B|AB|O)[+-]$',  
    'genetic_information': r'.+', 
    'immunization_records': r'.+',  
    'diagnostic_test_results': r'.+', 
    'is_diabetic': r'^(True|False)$',  
    'is_hyper_tension': r'^(True|False)$', 
    'is_smoker': r'^(True|False)$',  
    'is_alcoholic': r'^(True|False)$', 
    'has_undergone_surgery_in_past': r'^(True|False)$',  
    'allergic_to_medicine': r'^(True|False)$',  
    'name_of_allergic_medicine': r"^[a-zA-Z\s']+$" ,
    'is_physically_disabled': r'^(True|False)$'
}


    all_patterns = {**pii_patterns, **phi_patterns}

    def identify_pii_columns(df, patterns):
        pii_columns = {}
        for column in df.columns:
            for pii_type, regex in patterns.items():
                if df[column].astype(str).str.match(regex).any():
                    if pii_type not in pii_columns:
                        pii_columns[pii_type] = []
                    pii_columns[pii_type].append(column)
        return pii_columns

    df = validator.head()
    pii_columns = identify_pii_columns(df, all_patterns)

    for pii_type, columns in pii_columns.items():
        regex = all_patterns[pii_type]
        for column in columns:
            if column in df.columns:
                validator.expect_column_values_to_not_be_null(column)
                validator.expect_column_values_to_match_regex(column, regex)
                if column in unique_fields:
                    validator.expect_column_values_to_be_unique(column)

    validator.save_expectation_suite(discard_failed_expectations=False)

    checkpoint = context.add_or_update_checkpoint(
        name='dpe_test_checkpoint',
        validator=validator
    )

    checkpoint_result = checkpoint.run()
    validator.save_expectation_suite('gx_pox_result.json')

    validation_results = checkpoint_result["run_results"]

    results_list = []

    for key, result_container in validation_results.items():
        result = result_container["validation_result"]
        for expectation in result["results"]:
            expectation_config = expectation["expectation_config"]
            success = expectation["success"]
            details = expectation.get("result", {})
            unexpected_count = details.get("unexpected_count")
            unexpected_percent = details.get("unexpected_percent")
         
            if unexpected_count is None:
                unexpected_count = 'None'
            if unexpected_percent is None:
                unexpected_percent = '0'
            
            result_dict = {
                "Expectation": expectation_config["expectation_type"],
                "Column": expectation_config["kwargs"].get("column"),
                "Success": success,
                "Unexpected Count": unexpected_count,
                "Unexpected Percent": unexpected_percent
            }
            results_list.append(result_dict)

    results_df = pd.DataFrame(results_list)
    results_df.to_csv('validation_results.csv', index=False)

    print(results_df)

