import os
import stat
# import hashlib
# import magic
import pyclamd
import filetype


def scan_file_for_viruses(file_path):
    cd = pyclamd.ClamdNetworkSocket()
    if cd.ping():
        result = cd.scan_file(file_path)
        if result is None:
            print(f'No virus found in file: {file_path}')
            return True
        else:
            print(f'Virus found in file: {file_path}, details: {result}')
            return False
    else:
        print('Could not connect to ClamAV daemon')
        return False


def check_file_permissions(file_path):
    st = os.stat(file_path)
    permissions = stat.filemode(st.st_mode)
    print(f"\n------------------------------------------------------------------------------------------------------")
    print(f'\nPermissions for file {file_path}: {permissions}')
    return permissions


def validate_file_type(file_path, allowed_types):
    kind = filetype.guess(file_path)
    print(kind)
    if kind is None:
        return False  # Unknown file type
    return kind.mime in allowed_types


def get_file_type_result(fp):
    if validate_file_type(fp, 'csv'):
        print("\nValid 'csv' file")
    else:
        print("\nInvalid file type")
