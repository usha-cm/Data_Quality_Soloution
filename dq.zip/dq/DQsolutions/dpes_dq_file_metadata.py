import hashlib
import json
import os
from datetime import datetime
import csv
import chardet
import pandas as pd


# FINDING FILE ENCODE
def detect_csv_encoding(fpath):
    try:
        with open(fpath, 'rb') as f:
            rawdata = f.read(10000)
    except FileNotFoundError:
        print(f"Error: File not found: {fpath}")
        return None
    result = chardet.detect(rawdata)
    return result


# FINDING HEADER MATCH BETWEEN CONFIGURATION AND THE FILE
def find_header_match(df, jp):
    try:
        with open(jp, "r") as f:
            efile = json.load(open(jp))
            ehdr = efile["exp_emp_hdr"]

    except FileNotFoundError:
        print(f"Error: Configuration file not found: {jp}")

    headers = list(df.columns)
    if headers == ehdr:
        print(f"\n ✅ File headers are matching with the expected headers... \n")
    else:
        print(f"\n ⁉️ Headers do not match and they are: ")
        print(f" Expected headers: \n{ehdr}")
        print(f" Actual headers: \n{headers}\n")
    return df, headers


# GET CHECKSUM / HASH DETAILS
def get_checksum(fpath):
    with open(fpath, 'rb') as f:
        """Read file in chunks to avoid loading the entire file in memory"""
        data = f.read(65536)
        hasher = hashlib.md5()
        """Checksums with other algorithms like SHA-1 or SHA-256 by replacing hashlib.md5() with hashlib.sha1() or 
        hashlib.sha256(), respectively."""
        while data:
            hasher.update(data)
            data = f.read(65536)
    return hasher.hexdigest()


# FETCH & DISPLAY THE FILE PROPERTIES
def get_file_metadata(fp):
    fstats = os.stat(fp)
    encod = detect_csv_encoding(fp)
    if encod:
        filename, extension = os.path.splitext(fp)
        file_info_dict = {"File Type": extension,
                          "File Name": os.path.basename(fp),
                          "File Path": os.path.dirname(fp),
                          "File Size in KB": round(fstats.st_size / 1024, 2),
                          "File Size in MB": round(fstats.st_size / (1024 * 1024), 2),
                          "File Created Date & Time": datetime.fromtimestamp(fstats.st_mtime),
                          "File Modified Date & Time": datetime.fromtimestamp(fstats.st_ctime),
                          "File Encode": encod['encoding'],
                          "File Encode Confidence %": round(encod['confidence'] * 100, 2),
                          "CHECKSUM": get_checksum(fp)}
        print(
            f"\n***************************  📑 FILE REPORT FOR ETL / ELT or INGESTION  *************************** ")
        for fm in file_info_dict:
            print(f"{fm}  :   {file_info_dict[fm]}")
        print(
            f"****************************************************************************************************** ")
        return file_info_dict

    else:
        print("Encoding detection failed.")


# Load the first 100 rows from the CSV
def save_to_csv(fp):
    def infer_type(value):  # Function to infer data type of value
        try:
            int(value)
            return 'int'
        except ValueError:
            try:
                float(value)
                return 'float'
            except ValueError:
                try:
                    datetime.strptime(value, '%Y-%m-%d')
                    return 'date'
                except ValueError:
                    if value.lower() in ['true', 'false']:
                        return 'bool'
                    return 'str'

    with open(fp, mode='r', newline='') as csvfile:  # Ensure the file is opened in read mode
        reader = csv.reader(csvfile)
        headers = next(reader)
        # Initialize a dictionary to hold data types for each column
        column_types = {header: [] for header in headers}
        for i, row in enumerate(reader):
            if i >= 100:
                break
            for header, value in zip(headers, row):
                column_types[header].append(infer_type(value))

    # Determine the most frequent type for each column
    def most_frequent_type(types):
        return max(set(types), key=types.count)

    final_column_types = {header: most_frequent_type(types) for header, types in column_types.items()}

    # Save the result to a CSV file
    output_filename = 'column_data_types.csv'
    with open(output_filename, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Column_Name', 'Data_Type'])
        for header, data_type in final_column_types.items():
            writer.writerow([header, data_type])
    dt_df = pd.read_csv(output_filename)
    print(f"\nData types have been exported to '{output_filename}'\n\n")
    return dt_df
