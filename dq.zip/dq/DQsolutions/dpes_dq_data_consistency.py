import pandas as pd


def get_duplicate_file_rows(df):
    # Identify duplicate rows
    duplicates = df.duplicated()
    # Count the number of duplicate rows
    num_duplicates = duplicates.sum()
    return num_duplicates


def find_data_type_inconsistency(df):
    for column in df.columns:
        # Get the data types of each element in the column
        data_types = df[column].apply(type)

        # Find unique data types in the column
        unique_data_types = data_types.unique()

        # Print the unique data types
        print(f'Unique data types in column "{column}": {unique_data_types}')

        # Check if there are more than one data type
        if len(unique_data_types) > 1:
            print(f'Column "{column}" contains multiple data types.')
        else:
            print(f'Column "{column}" contains a single data type.')

        print('-' * 40)
